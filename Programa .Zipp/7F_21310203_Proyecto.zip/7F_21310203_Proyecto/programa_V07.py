import tkinter as tk
from tkinter import messagebox
import pandas as pd
import os
from tkinter import *
from PIL import Image, ImageTk 

# Cargar la base de datos de sensores desde un archivo Excel
file_path = "sensores_base_datos.xlsx"
df = pd.read_excel(file_path)

# Lista de preguntas para el sistema experto
preguntas = [
    "¿El sensor debe medir temperatura?",
    "¿El sensor necesita detectar presión o vibraciones?",
    "¿El sensor debe operar en ambientes controlados de luz?",
    "¿El sensor debe detectar objetos a distancia mediante luz?",
    "¿El sensor debe monitorear campos magnéticos?",
    "¿El sensor necesita detectar materiales metálicos?",
    "¿El sensor debe detectar materiales no metálicos o líquidos?",
    "¿El sensor debe controlar límites físicos o movimientos mecánicos?",
    "¿El sensor debe ser resistente a condiciones extremas de temperatura?",
    "¿El sensor necesita medir niveles de líquidos?",
    "¿El sensor debe operar en ambientes con alta humedad?",
    "¿El sensor debe ser capaz de medir flujo de aire?",
    "¿El sensor necesita detectar presencia humana?",
    "¿El sensor debe ser inalámbrico?",
    "¿El sensor necesita medir velocidad o aceleración?",
    "¿El sensor debe ser compacto para espacios pequeños?",
    "¿El sensor debe medir fuerza aplicada?",
    "¿El sensor necesita funcionar en ambientes polvorientos?",
    "¿El sensor debe medir niveles de radiación?",
    "¿El sensor debe ser capaz de operar bajo el agua?",
]

# Asociación de preguntas con sensores
asociaciones = {
    "Sensor de Temperatura": [0, 8],
    "Sensor Piezoeléctrico": [1, 16],
    "Sensor Óptico": [2, 3],
    "Sensor Fotoeléctrico": [3, 12],
    "Sensor Magnético": [4],
    "Sensor Inductivo": [5],
    "Sensor Capacitivo": [6, 9],
    "Sensor de Límite": [7],
    "Sensor de Humedad": [10, 11],
    "Sensor de Flujo": [11],
    "Sensor de Proximidad": [12, 13],
    "Sensor de Velocidad": [14],
    "Sensor de Radiación": [18],
    "Sensor Subacuático": [19],
    "Sensor de Presión": [1, 16],
    "Sensor de Fuerza": [16],
    "Sensor Compacto": [15],
    "Sensor de Polvo": [17],
    "Sensor Inalámbrico": [13],
}
#variables globales
ventana_funcionamiento_abierta = False

########################################################################################################
##VENTANA 1
def mostrar_introduccion():
    ventana1 = tk.Tk()
    ventana1.title("Ventana 1: Introducción")
    ventana1.geometry("1280x720")

    # Cargar la imagen Frame1 usando Pillow
    imagen = Image.open("Frame1.jpg")  # Asegúrate de que el archivo Frame1.jpg esté en el directorio correcto
    imagen = ImageTk.PhotoImage(imagen)  # Convertirla al formato que Tkinter pueda manejar

    # Crear un Label para mostrar la imagen
    etiqueta_imagen = tk.Label(ventana1, image=imagen)
    etiqueta_imagen.pack(expand=True)

    # Mostrar un mensaje
    #mensaje = tk.Label(ventana1, text="¿Qué sensor vamos a escoger?", font=("Arial", 24))
    #mensaje.pack(expand=True)

    def cerrar_intro():
        ventana1.destroy()
        mostrar_menu()

    ventana1.after(5000, cerrar_intro)
    ventana1.mainloop()

# Llamada a la función
#mostrar_introduccion()


########################################################################################################
##########VENTANA 3
def abrir_db():
    archivo = "sensores_base_datos.xlsx"
    if os.path.exists(archivo):
        try:
            os.startfile(archivo)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir el archivo: {e}")
    else:
        messagebox.showerror("Error", "El archivo sensores_base_datos.xlsx no existe.")

# Función para abrir el registro de cotizaciones
def abrir_registro():
    archivo = "cotizaciones.xlsx"
    if os.path.exists(archivo):
        try:
            os.startfile(archivo)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir el archivo: {e}")
    else:
        messagebox.showerror("Error", "El archivo cotizaciones.xlsx no existe.")

def mostrar_funcionamiento():
    messagebox.showinfo("Funcionamiento",  "En este menú encontrarás 3 Opciones:\n\n"
        "1.- Abrir registro de Cotizaciones:\n   Abrirás la Base de datos de las cotizaciones hechas previamente por nuestro sistema experto.\n\n"
        "2.- Abrir lista de sensores:\n   En este apartado vas a encontrar la base de datos de nuestros sensores, los cuales nuestro sistema experto va a recomendar en base a tus necesidades.\n\n"
        "3.- Comenzar:\n   Con este apartado comenzará un cuestionario para determinar el sensor ideal para ti."
    )



# Función para mostrar el menú
def mostrar_menu():
    ventana3 = tk.Tk()
    ventana3.title("Ventana 3: Menú")
    ventana3.geometry("1280x720")

    # Cargar la imagen de fondo
    try:
        imagen_fondo = Image.open("Frame41.png")
        imagen_fondo = imagen_fondo.resize((1280, 720))  # Ajustar el tamaño al de la ventana
        imagen_fondo_tk = ImageTk.PhotoImage(imagen_fondo)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo cargar la imagen de fondo: {e}")
        ventana3.destroy()
        return
    
    
    # Crear un label para la imagen de fondo
    label_fondo = tk.Label(ventana3, image=imagen_fondo_tk)
    label_fondo.place(x=0, y=0, relwidth=1, relheight=1)

    # Botón para abrir la lista de sensores
    boton_ver_db = tk.Button(ventana3, text="abrir lista de sensores", font=("Arial", 14), command=abrir_db)
    boton_ver_db.place(x=416, y=334)

    # Botón para abrir el registro de cotizaciones
    boton_ver_registro = tk.Button(ventana3, text="Abrir registro de cotizaciones", font=("Arial", 14), command=abrir_registro)
    boton_ver_registro.place(x=416, y=82)

    # Botón para continuar
    boton_continuar = tk.Button(ventana3, text="Comenzar", font=("Arial", 16), command=lambda: [ventana3.destroy(), mostrar_preguntas()])
    boton_continuar.place(x=416, y=568)

     ###### Función para detectar si el mouse está dentro del área específica
    def detectar_mouse(event):
        # Coordenadas del área central (1205, 653) con un radio de 70
        x_centro, y_centro, radio = 1200, 650, 35
        distancia = ((event.x - x_centro) ** 2 + (event.y - y_centro) ** 2) ** 0.5
        if distancia <= radio:
            mostrar_funcionamiento()

    # Asociar el evento de movimiento del mouse
    ventana3.bind("<Motion>", detectar_mouse)


    # Asociar eventos de teclado
    ventana3.bind("<KeyPress>", manejar_tecla)

    # Mantener referencia de la imagen
    ventana3.imagen_fondo_tk = imagen_fondo_tk  # Importante: Evita que la imagen sea recolectada por el garbage collector

    # Ejecutar la ventana
    ventana3.mainloop()

# Función de ejemplo para manejar las preguntas (puedes reemplazarla con la real)
def mostrar_preguntas():
    print("Mostrando preguntas...")

# Función de ejemplo para manejar teclas (puedes reemplazarla con la real)
def manejar_tecla(event):
    print(f"Tecla presionada: {event.char}")

# Llamar a la función principal
#mostrar_menu()


########################################################################################################
###ventana 2####
def mostrar_preguntas():
    respuestas = []
    pregunta_actual = 0

    ventana2 = tk.Tk()
    ventana2.title("Ventana 2: Sistema Experto")
    ventana2.geometry("1280x720")
#################################################################
        # Cargar la imagen de fondo
    try:
        imagen_fondo2 = Image.open("Frame52.png")
        imagen_fondo2 = imagen_fondo2.resize((1280, 720))  # Ajustar el tamaño de la imagen al de la ventana
        imagen_fondo_tk2 = ImageTk.PhotoImage(imagen_fondo2)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo cargar la imagen de fondo: {e}")
        ventana2.destroy()
        return

    # Crear un label para la imagen de fondo
    label_fondo = tk.Label(ventana2, image=imagen_fondo_tk2)
    label_fondo.place(x=0, y=0, relwidth=1, relheight=1)
######################################################################

    pregunta_label = tk.Label(ventana2, text="", font=("Arial", 30), wraplength=800, justify="center")
    pregunta_label.pack(pady=20)
    pregunta_label.place(x=254, y = 191)

    opcion = tk.IntVar(value=-1)

    # Crear botones de opción "Sí" y "No"
    si_button = tk.Radiobutton(ventana2, text="Sí", variable=opcion, value=1, font=("Arial", 25))
    si_button.pack()
    si_button.place(x=375, y=400) 

    no_button = tk.Radiobutton(ventana2, text="No", variable=opcion, value=0, font=("Arial", 25))
    no_button.pack()
    no_button.place(x=750, y=400)  # Usar coordenadas específicas para mayor control

    # Botón para continuar a la siguiente pregunta
    continuar_button = tk.Button(ventana2, text="Continuar", font=("Arial", 30), command=lambda: manejar_respuesta())
    continuar_button.pack(pady=20)
    continuar_button.place(x=488  , y=452)
    
    def mostrar_pregunta():
        if pregunta_actual < len(preguntas):
            pregunta_label.config(text=preguntas[pregunta_actual])
            opcion.set(-1)  # Reiniciar selección de opciones
        else:
            procesar_respuestas()

    def procesar_respuestas():
        sensores_recomendados = []
        for sensor, indices in asociaciones.items():
            if all(respuestas[i] == 1 for i in indices):
                sensores_recomendados.append(sensor)

        ventana2.destroy()
        mostrar_ventana4(sensores_recomendados)

    def manejar_respuesta():
        nonlocal pregunta_actual
        seleccion = opcion.get()
        if seleccion != -1:  # Asegurarse de que una opción esté seleccionada
            respuestas.append(seleccion)
            pregunta_actual += 1
            mostrar_pregunta()

    def manejar_tecla(event):
        nonlocal pregunta_actual
        if event.char.lower() == 's':
            opcion.set(1)
            manejar_respuesta()
        elif event.char.lower() == 'n':
            opcion.set(0)
            manejar_respuesta()

    ventana2.bind("<KeyPress>", manejar_tecla)

    mostrar_pregunta()
    ventana2.mainloop()


########################################################################################################
# Ventana 4: Registro de datos


def mostrar_ventana4(sensores_recomendados):
    ventana4 = tk.Tk()
    ventana4.title("Ventana 4: Registro de Datos")
    ventana4.geometry("1280x720")

           # Cargar la imagen de fondo
    try:
        imagen_fondo4 = Image.open("Frame8.png")
        imagen_fondo4 = imagen_fondo4.resize((1280, 720))  # Ajustar el tamaño de la imagen al de la ventana
        imagen_fondo_tk4 = ImageTk.PhotoImage(imagen_fondo4)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo cargar la imagen de fondo: {e}")
        ventana4.destroy()
        return

    # Crear un label para la imagen de fondo
    label_fondo = tk.Label(ventana4, image=imagen_fondo_tk4)
    label_fondo.place(x=0, y=0, relwidth=1, relheight=1)

    tk.Label(ventana4, text="Nombre", font=("Arial", 14)).grid(row=0, column=0, padx=10, pady=10)
    tk.Label(ventana4, text="Correo Electrónico", font=("Arial", 14)).grid(row=1, column=0, padx=10, pady=10)
    tk.Label(ventana4, text="Empresa", font=("Arial", 14)).grid(row=2, column=0, padx=10, pady=10)

    nombre_entry = tk.Entry(ventana4, font=("Arial", 14))
    correo_entry = tk.Entry(ventana4, font=("Arial", 14))
    empresa_entry = tk.Entry(ventana4, font=("Arial", 14))

    nombre_entry.grid(row=0, column=1, padx=10, pady=10)
    correo_entry.grid(row=1, column=1, padx=10, pady=10)
    empresa_entry.grid(row=2, column=1, padx=10, pady=10)

    # Mostrar sensores recomendados como texto
    tk.Label(ventana4, text="Sensores Recomendados", font=("Arial", 14)).grid(row=3, column=0, padx=10, pady=10)
    sensores_text = tk.Text(ventana4, font=("Arial", 14), height=10, width=40)
    sensores_text.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

    sensores_text.insert(tk.END, "\n".join(sensores_recomendados))
    sensores_text.config(state=tk.DISABLED)

    def guardar_datos():
        nombre = nombre_entry.get()
        correo = correo_entry.get()
        empresa = empresa_entry.get()

        if not nombre or not correo or not empresa:
            messagebox.showwarning("Advertencia", "Por favor complete todos los campos.")
            return

        datos = {
            "Nombre": [nombre],
            "Correo Electrónico": [correo],
            "Empresa": [empresa],
            "Sensores Recomendados": ["; ".join(sensores_recomendados)]
        }

        if os.path.exists("cotizaciones.xlsx"):
            df_existente = pd.read_excel("cotizaciones.xlsx")
            df_nuevo = pd.DataFrame(datos)
            df_actualizado = pd.concat([df_existente, df_nuevo], ignore_index=True)
            df_actualizado.to_excel("cotizaciones.xlsx", index=False)
        else:
            df_nuevo = pd.DataFrame(datos)
            df_nuevo.to_excel("cotizaciones.xlsx", index=False)
        messagebox.showinfo("Éxito", "Datos guardados correctamente. La base de datos ha sido actualizada.")
        ventana4.destroy()
        mostrar_menu()

    boton_guardar = tk.Button(ventana4, text="Guardar", font=("Arial", 14), command=guardar_datos)
    boton_guardar.grid(row=5, column=0, pady=20)

    def regresar_menu():
        ventana4.destroy()
        mostrar_menu()

    boton_menu = tk.Button(ventana4, text="Menú", font=("Arial", 14), command=regresar_menu)
    boton_menu.grid(row=5, column=1, pady=20)

    ventana4.mainloop()

#def mostrar_menu():
    # Placeholder function to simulate returning to a menu.
    pass

# Ejemplo de llamada
# mostrar_ventana4(["Sensor óptico", "Sensor de temperatura"])


# Iniciar el programas
mostrar_introduccion()
